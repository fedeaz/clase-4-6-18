#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE* f;
    int id;
    char marca[20];
    char modelo[20];
    char color[20];
    int anio;
    int cant;

    //abre el archivo
    f = fopen("MOCKA DATA.csv", "r");
    //verifica que no sea null, que lo pueda leer, que existe
    if(f==NULL)
    {
        printf("no se pudo abrir\n\n");
        exit(EXIT_FAILURE);
    }

    //
     while(!feof(f))
     {
         cant = fscanf(f,"%d, %[^,], %[^,], %[^,], %d, %d,\n", &id,marca,modelo,color,&anio);

     if(cant !=5)
     {
         if(feof(f))
         {
             //por si leyo bien el archivo
             break;
         }
         else
         {
             //por si no llego a leer el total del archivo
             printf("hubo un error\m");
             exit(EXIT_FAILURE);
         }
     }
         printf("%4d %16s %16s %16s %4d\n", id,marca,modelo,color,anio);
    }



    return 0;
}
