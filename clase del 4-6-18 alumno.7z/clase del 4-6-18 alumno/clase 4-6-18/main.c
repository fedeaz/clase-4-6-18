#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE* f;
    int num1,num2,num3,num4;
    int cant;

    f = fopen("datos.txt", "r");
    if(f==NULL)
    {
        printf("no se pudo abrir\n\n");
        exit(EXIT_FAILURE);
    }

    while(!feof(f))
    {
        cant = fscanf(f,"%d, %d, %d, %d\n", &num1, &num2, &num3, &num4 );



        if(cant != 4)
        {
            if(feof(f))
            {
                break;
            }

        else
        {
            printf("hubo un problema \n");
            exit(EXIT_FAILURE);
        }
        }
        printf("%d, %d, %d, %d\n", num1,num2,num3,num4);
    }



    return 0;
}
